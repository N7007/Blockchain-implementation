const express = require("express");
const path = require("path");
const app = express();

app.use("/public", express.static(__dirname + "/public"));

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname + "/index.html"));
})

app.get("/votacion", (req, res) => {
    res.sendFile(path.join(__dirname + "/votacion.html"));
})

//192.168.56.1:5000
const server = app.listen(5000);
const portNumber = server.address().port;
console.log(`port is open on ${portNumber}`);